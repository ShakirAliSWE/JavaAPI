/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ImplodeAndExplodeFunction;

/**
 *
 * @author Shakir Ali Mughal
 */
public class ImplodeAndExplodeFunction {

    public String implode(String delimator,String ArrrayOfString[])
    {
        String implodAns = "";
        for(String s :ArrrayOfString)
        {
            implodAns = implodAns+s+delimator;
        }
        return implodAns;
    }
    
    public String[] explode(String delimator,String string)
    {
        StringBuilder sb = new StringBuilder();
        String[] array = string.split(delimator);
        String[] explodeAns = new String[array.length];
        for (int i = 0; i < array.length; i++) 
        {
            explodeAns[i] = array[i];
        }
        return explodeAns;
    }
    
    
}
